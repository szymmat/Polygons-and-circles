﻿using System.Windows;

namespace Lab1
{
    /// <summary>
    /// Logika interakcji dla klasy WindowPolygon.xaml
    /// </summary>
    public partial class WindowPolygon : Window
    {
        public WindowPolygon()
        {
            InitializeComponent();
        }

        private void okButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }
    }
}
